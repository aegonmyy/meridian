# NoQuarantinedReport
[Git Source](https://github.com/aegonmyy/meridian/blob/93c662cb67fbace267d9454dbfc727c4ea6b0491/src/errors/hubErrors.sol)

Thrown when accept/rejectQuarantinedReport is called for a selector with no quarantined report


```solidity
error NoQuarantinedReport();
```

